package accumulators;

public class IntAccumulator {
	
	private int sum = 0;
	private int n = 0;
	
	public int getSum() {return sum;}
	public void setSum(int sum) {this.sum = sum;}
	public int getN() {	return n;}
	public void setN(int n) {this.n = n;}
	
	

}
