package accumulators;

public class DoubleAccumulator {
	private double sum = 0;
	private int n = 0;
	
	public double getSum() {return sum;}
	public void setSum(double sum) {this.sum = sum;}
	public int getN() {	return n;}
	public void setN(int n) {this.n = n;}
}
