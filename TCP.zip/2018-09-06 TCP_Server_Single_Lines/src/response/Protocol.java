package response;

public interface Protocol {
	String getResponse(String request);
}
