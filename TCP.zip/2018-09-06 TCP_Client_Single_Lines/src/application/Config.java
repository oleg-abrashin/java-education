package application;

public interface Config {
	
	static final String HOST = "localhost";
	static final int PORT = 2000;
	static final String EXIT = "quit";

}
