package response;

public interface Protocol {
	Object getResponse(Object request);
}
